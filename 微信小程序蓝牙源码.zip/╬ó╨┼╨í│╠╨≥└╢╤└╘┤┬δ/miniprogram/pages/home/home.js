// 获取到小程序实例
var app = getApp();
Page({
	data: {
		shop:{
			name:'食惠客',
			desc:'凡在本店办理会员，一律享受8.8折优惠'
		},
		goods: {
			1: {
				id: 1,
				name: '排骨',
        pic: 'http://m.meishidajie.com/uploads/allimg/160112/2-160112101334E3.jpg',
				sold: 1014,
				price: 12
			},
			2: {
				id: 2,
				name: '香菇鸡翅',
        pic: 'http://m.meishidajie.com/uploads/allimg/171028/2-1G02R14235H3.jpg',
				sold: 1029,
				price: 12
			},
			3: {
				id: 3,
				name: '牙签肉',
        pic: 'http://m.meishidajie.com/uploads/allimg/171027/2-1G02G15202917.jpg',
				sold: 1030,
				price: 8
			},
			4: {
				id: 4,
				name: '青椒鸡蛋',
        pic: 'http://m.meishidajie.com/uploads/allimg/171105/2-1G10514225VV.jpg',
				sold: 1059,
				price: 8
			},
			5: {
				id: 5,
				name: '烤鸭',
        pic: 'http://m.meishidajie.com/uploads/allimg/171026/2-1G026144U5F8.jpg',
				sold: 1029,
				price: 10
			},
			6: {
				id: 6,
				name: '蔬菜粥',
        pic: 'http://m.meishidajie.com/uploads/allimg/171025/2-1G02510162Y38.jpg',
				sold: 1064,
				price: 3
			},
			7: {
				id: 7,
				name: '玉米粥',
        pic: 'http://m.meishidajie.com/uploads/allimg/171024/2-1G024215645113.jpg',
				sold: 814,
				price: 3
			},
			8: {
				id: 8,
				name: '瘦肉粥',
        pic: 'http://m.meishidajie.com/uploads/allimg/170916/2-1F91609110VT.jpg',
				sold: 124,
				price: 5
			},
			9: {
				id: 9,
				name: '雪碧',
        pic: '/images/xuebi.jpg',
				sold: 102,
				price: 4
      },
      10: {
        id: 10,
        name: '果汁',
        pic: '/images/guozhi.jpg',
        sold: 102,
        price: 4
      },
      11: {
        id: 11,
        name: '米饭',
        pic: '/images/mifan.jpg',
        sold: 102,
        price: 1.5
      },
      12: {
        id: 12,
        name: '馒头',
        pic: '/images/mantou.jpg',
        sold: 102,
        price: 0.5
      }
		},
		goodsList: [
			{
				id: 'hot',
				classifyName: '热销',
				goods: [1, 2, 3, 4, 5]
			},
			{
				id: 'new',
				classifyName: '炒菜',
				goods: [2, 4]
			},
			{
				id: 'vegetable',
				classifyName: '米粥',
				goods: [ 6, 7, 8]
			},
			{
				id: 'mushroom',
				classifyName: '饮料',
				goods: [ 9, 10]
			},
			{
				id: 'food',
				classifyName: '主食',
				goods: [11, 12]
			}
		],
		cart: {
			count: 0,
			total: 0,
			list: {}
		},
		cartList:{},
		showCartDetail: false
	},
	// 生命周期函数--监听页面加载
	// 一个页面只会调用一次。
	onLoad: function (options) {
		
	},
	// 生命周期函数--监听页面初次渲染完成
	onReady: function(){},
	// 生命周期函数--监听页面显示
	// 每次打开页面都会调用一次
	onShow: function () {
		this.setData({
			classifySeleted: this.data.goodsList[0].id
		});
	},
	// 生命周期函数--监听页面隐藏
	// 当navigateTo或底部tab切换时调用
	onHide: function(){},
	// 生命周期函数--监听页面卸载
	// 当redirectTo或navigateBack的时候调用。
	onUnload:function(){},
	// 页面相关事件处理函数--监听用户下拉动作
	onPullDownRefresh:function(){},
	// 页面上拉触底事件的处理函数
	onReachBottom:function(){},

	// 开发者可以添加任意的函数或数据到
	//  object 参数中，在页面的函数中用 this 可以访问
	checkOrderSame: function(name){
		var list = this.data.goods;
		for(var index in list){
			if(list[index].name === name){
				return index;
			}
		}
		return false;
	},
	tapAddCart: function (e) {
		this.addCart(e.target.dataset.id);
	},
	tapReduceCart: function (e) {
		this.reduceCart(e.target.dataset.id);
	},
	addCart: function (id) {
		var num = this.data.cart.list[id] || 0;
		this.data.cart.list[id] = num + 1;
		this.countCart();
		var price = this.data.goods[id].price;
		var name  = this.data.goods[id].name;
		var img   = this.data.goods[id].pic;
		var list  = this.data.cartList;
		var sortedList = [];
		var index;
		if(index = this.checkOrderSame(name)){
			sortedList = list[index];
			var num = this.data.cart.list[id] || 0;
			num = num + 1;
		}
		else{
			var order = {
				"price" : price,
				"num" : 1,
				"name": name,
				'img':  img,
				"shopId": this.data.shopId,
				"shopName": this.data.shop.restaurant_name,
				"pay": 0,
			}
			list.push(order);
			sortedList = order;
		}
		this.setData({
			cartList: list,
		});
	},
	reduceCart: function (id) {
		var num = this.data.cart.list[id] || 0;
		if (num <= 1) {
			delete this.data.cart.list[id];
		} else {
			this.data.cart.list[id] = num - 1;
		}
		this.countCart();
	},
	countCart: function (index,lists) {
		var count = 0,
			total = 0;
		var goods;
		for (var id in this.data.cart.list) {
		    goods = this.data.goods[id];
			count += this.data.cart.list[id];
			total += goods.price * this.data.cart.list[id];
		}
		this.data.cart.count = count;
		this.data.cart.total = total;
		this.setData({
			cart: this.data.cart
		});
		// 存储订单页所需要的数据
		wx.setStorage({
			key: 'orderList',
			data: {
				count: this.data.cart.count,
				total: this.data.cart.total,
				list: this.data.cart.list,
			}
		})
		
	},
	follow: function () {
		this.setData({
			followed: !this.data.followed
		});
	},
	onGoodsScroll: function (e) {
		if (e.detail.scrollTop > 10 && !this.data.scrollDown) {
			this.setData({
				scrollDown: true
			});
		} else if (e.detail.scrollTop < 10 && this.data.scrollDown) {
			this.setData({
				scrollDown: false
			});
		}

		var scale = e.detail.scrollWidth / 570,
			scrollTop = e.detail.scrollTop / scale,
			h = 0,
			classifySeleted,
			len = this.data.goodsList.length;
		this.data.goodsList.forEach(function (classify, i) {
			var _h = 70 + classify.goods.length * (46 * 3 + 20 * 2);
			if (scrollTop >= h - 100 / scale) {
				classifySeleted = classify.id;
			}
			h += _h;
		});
		this.setData({
			classifySeleted: classifySeleted
		});
	},
	tapClassify: function (e) {
		var id = e.target.dataset.id;
		this.setData({
			classifyViewed: id
		});
		var self = this;
		setTimeout(function () {
			self.setData({
				classifySeleted: id
			});
		}, 100);
	},
	showCartDetail: function () {
		this.setData({
			showCartDetail: !this.data.showCartDetail
		});
	},
	hideCartDetail: function () {
		this.setData({
			showCartDetail: false
		});
	},
	submit: function (e) {
		var agrs = JSON.stringify(this.data.cart);
		}
});